from .models import db
from .models import ClUser, Person, Customer, PersonDtl, PersonBankAccount

__all__ = ["db", "ClUser", "Person", "Customer", "PersonDtl", "PersonBankAccount"]
